package org.onerelease.calculators;

import org.onerelease.enumeration.*;
import org.openxava.calculators.*;

public class DefaultUSStatus implements ICalculator {

	@Override
	public Object calculate() throws Exception {
		// TODO Auto-generated method stub
		return TicketStatus.Created;
	}

}
