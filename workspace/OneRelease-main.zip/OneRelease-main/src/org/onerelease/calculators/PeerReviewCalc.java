package org.onerelease.calculators;

import org.openxava.calculators.*;

public class PeerReviewCalc implements ICalculator {

	@Override
	public Object calculate() throws Exception {
		// TODO Auto-generated method stub
		return "4028818a7493f40e017493fb5a8f0005";
	}

	
	
	
}
