package org.onerelease.enumeration;

public enum LocationFunctionalityAnalysis { FunctionalityDescription, 
	FunctionalityDiagram, FunctionalityFunctional, TechnicalImpacts, 
	TestingStrategies

}
