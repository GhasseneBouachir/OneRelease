package org.onerelease.enumeration;

public enum TicketBySprintStatus { initiated,started, toBeContinued, finished
}
