package org.onerelease.enumeration;

public enum Milestone { Ana, EndANA, Dev, EndDEV, IST, EndIST

}
