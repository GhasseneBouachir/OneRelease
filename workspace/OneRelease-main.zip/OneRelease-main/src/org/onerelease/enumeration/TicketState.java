package org.onerelease.enumeration;

public enum TicketState { toDO,InProgress,finished

}
