package org.onerelease.enumeration;

public enum SprintStatus { planned, activated, terminated 

}
