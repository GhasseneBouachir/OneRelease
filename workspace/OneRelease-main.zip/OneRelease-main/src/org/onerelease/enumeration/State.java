package org.onerelease.enumeration;

public enum State { OK,KO

}
