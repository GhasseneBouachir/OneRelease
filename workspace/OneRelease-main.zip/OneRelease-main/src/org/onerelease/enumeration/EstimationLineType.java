package org.onerelease.enumeration;

public enum EstimationLineType {
Major, Minor
}
