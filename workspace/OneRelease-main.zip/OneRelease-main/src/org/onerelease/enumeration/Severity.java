package org.onerelease.enumeration;

public enum Severity { Minor, Major

}
