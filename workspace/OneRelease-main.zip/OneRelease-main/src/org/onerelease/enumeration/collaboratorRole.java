package org.onerelease.enumeration;

public enum collaboratorRole {
ScrumMaster,Tester, Integrator, BusinessAnalyst, Developer, Manager 
}
