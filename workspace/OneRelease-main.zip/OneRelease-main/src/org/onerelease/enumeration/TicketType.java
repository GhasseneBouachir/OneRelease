package org.onerelease.enumeration;

public enum TicketType  {
	Request, Anomaly, Requirement, Enhancement
}
