package org.onerelease.enumeration;

public enum EstimationType {
Initial, Revised, Final
}
