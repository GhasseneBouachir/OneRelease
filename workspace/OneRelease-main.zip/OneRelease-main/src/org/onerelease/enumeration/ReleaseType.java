package org.onerelease.enumeration;

public enum ReleaseType {
	Major, Minor
}
