package org.onerelease.enumeration;

public enum FunctionType {
Ergonomic, Procedure, UserInterface
}
