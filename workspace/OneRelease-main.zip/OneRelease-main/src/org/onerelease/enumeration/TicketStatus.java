package org.onerelease.enumeration;

public enum TicketStatus {
Created, Acknowledged, Opened, InProgress, Resolved, Closed
}
