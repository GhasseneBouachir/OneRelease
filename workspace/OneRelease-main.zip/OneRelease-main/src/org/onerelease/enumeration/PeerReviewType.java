package org.onerelease.enumeration;

public enum PeerReviewType { Formal, Walkthrough, IndividualReview

}
