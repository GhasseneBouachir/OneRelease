package org.onerelease.enumeration;

public enum TicketPriority {
Low, Medium, Urgent, Critical
}
