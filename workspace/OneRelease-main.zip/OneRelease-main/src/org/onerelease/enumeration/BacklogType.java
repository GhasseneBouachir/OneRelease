package org.onerelease.enumeration;

public enum BacklogType { BUG, ChangeRequest, Enhancement

}
