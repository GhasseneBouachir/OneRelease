package org.lesstif.jira.issue;

public class Progress {
	 private float progress;
	 private float total;


	 // Getter Methods 

	 public float getProgress() {
	  return progress;
	 }

	 public float getTotal() {
	  return total;
	 }

	 // Setter Methods 

	 public void setProgress(float progress) {
	  this.progress = progress;
	 }

	 public void setTotal(float total) {
	  this.total = total;
	 }
	}