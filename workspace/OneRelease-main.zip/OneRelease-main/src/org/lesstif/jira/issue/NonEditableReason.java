package org.lesstif.jira.issue;

public class NonEditableReason {
	 private String reason;
	 private String message;


	 // Getter Methods 

	 public String getReason() {
	  return reason;
	 }

	 public String getMessage() {
	  return message;
	 }

	 // Setter Methods 

	 public void setReason(String reason) {
	  this.reason = reason;
	 }

	 public void setMessage(String message) {
	  this.message = message;
	 }
	}