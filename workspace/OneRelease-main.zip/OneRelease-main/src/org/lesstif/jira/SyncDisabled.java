package org.lesstif.jira;

public class SyncDisabled extends Exception {



	public SyncDisabled(String message) {
		super(message);
	}



}
